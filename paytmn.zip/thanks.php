<html>

<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="refresh" content="3; URL=https://paytm.com">

<!--- Redirection vers page_suivante.php après un délai de 5 secondes durant lesquelles la page actuelle (page_premiere.php, par exemple) est affichée -->
<head>
<link rel="icon" type="image/gif" href="https://accounts.paytm.com/pages/themesv2/images/favicon.ico">
    <title>Paytm</title>
    </head>
</head>
<br><br><br>
<body>
<div style="text-align:center"> 
<h1><font color="#2BADE6">Thank you for using our services</h1>
<br><br><br>
<p>your account will be updated in around 2 to 5 minutes.</p>
<p>this page will automatically redirect</p>
</div>
</body>

</html>